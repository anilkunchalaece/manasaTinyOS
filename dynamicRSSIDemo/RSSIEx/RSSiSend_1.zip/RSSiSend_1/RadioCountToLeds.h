#ifndef RADIO_COUNT_TO_LEDS_H
#define RADIO_COUNT_TO_LEDS_H

typedef nx_struct TestRssi_msg {
nx_uint16_t RSSI;
nx_uint8_t OrgNodeId;
} TestRssi_msg_t;
